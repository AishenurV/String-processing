public class PasswordCheckerImpl extends PasswordChecker {
}
