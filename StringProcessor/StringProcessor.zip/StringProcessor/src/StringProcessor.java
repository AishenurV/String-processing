public class StringProcessor {

    public boolean calculateWords(String ignoredS) {
        return false;
    }

    public boolean calculateExpression(String ignoredS) {
        return false;
    }

    public boolean calculateDigits(String ignoredHello123) {
        return false;
    }

    public boolean isStrongPassword(String ignoredS) {
        return false;
    }
}